const fs = require('fs')
const path = require('path')
const exec = require('child_process').exec

module.exports = function(projectPath, newappname, oldpkg, newpkg) {
  let oldpkg_ = path.join(projectPath, './app/src/main/java', "./"+oldpkg.replaceAll('.', '/'))
  let newpkg_ = path.join(projectPath, './app/src/main/java', "./"+newpkg.replaceAll('.', '/'))

  function editFiles(dir) {
    fs.readdirSync(dir).filter(f=>f.endsWith('.java')||fs.statSync(path.join(dir, f)).isDirectory()).forEach(file => {
      if(fs.statSync(path.join(dir, file)).isDirectory()) return editFiles(path.join(dir, file))

      let contents = fs.readFileSync(path.join(dir, file), 'utf-8')
      contents = contents.replaceAll(oldpkg, newpkg)

      fs.writeFileSync(path.join(dir, file), contents)
    })
    newPkg(0)
  }
  function rmOldpkg() {
    let first = oldpkg.split('.')[0]

    let pth = path.join(projectPath, './app/src/main/java', first)
    let pth2 = path.join(projectPath, './app/build/gen', first)
    
    fs.rmSync(pth,{recursive:true})
    fs.rmSync(pth2,{recursive:true})

    return true
  }
  
  function secondNewPkg(i) {
    let last = path.join(projectPath, './app/build/gen')
    let packageFolders = newpkg.split('.').map(v => {
      last = path.join(last, v)
      return last
    })

    if(i>=packageFolders.length) {
      exec(`mv ${path.join(projectPath, './app/build/gen', "./"+oldpkg.replaceAll('.', '/'))}/* ${packageFolders[packageFolders.length-1]}`)
      androidManifestEdit()
      return/* rmOldpkg()*/
    }

    let folder = packageFolders[i]
    fs.mkdirSync(folder, { recursive: true })

    return secondNewPkg(i+1)
  }
  
  function newPkg(i) {
    let last = path.join(projectPath, './app/src/main/java')
    let packageFolders = newpkg.split('.').map(v => {
      last = path.join(last, v)
      return last
    })
    
    if(i>=packageFolders.length) {
      exec(`mv ${oldpkg_}/* ${newpkg_}`)
      return secondNewPkg(0)
    }

    let folder = packageFolders[i]
    fs.mkdirSync(folder, { recursive: true })

    return newPkg(i+1)
  }
  
  function androidManifestEdit() {
    let androidManifestPath = path.join(projectPath, './app/src/main/AndroidManifest.xml')
    let contents = fs.readFileSync(androidManifestPath, "utf-8")
    contents = contents.replaceAll(oldpkg, newpkg)
    fs.writeFileSync(androidManifestPath, contents)
    appNameEdit()
  }
  function appNameEdit() {
    let stringsPath = path.join(projectPath, './app/src/main/res/values/strings.xml')
    let contents = fs.readFileSync(stringsPath, "utf-8")
    contents = contents.replaceAll('<string name="app_name">WebView</string>', `<string name="app_name">${newappname}</string>`)
    fs.writeFileSync(stringsPath, contents)
  }

  editFiles(path.join(projectPath, './app/'))
  return true
}