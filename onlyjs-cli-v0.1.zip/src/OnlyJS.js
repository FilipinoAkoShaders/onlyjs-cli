const fs = require('fs')
const path = require('path')
const AdmZip = require('adm-zip')
const modifyApp = require('./editPackage.js')
const codeParse = require('./parser.js')

fs.rmSync(path.join(__dirname, 'projects'), {recursive:true})
fs.mkdirSync(path.join(__dirname, 'projects'))
function newApp(output,data,id) {
  let { name, package, orientation, code, iconPath } = data 

  if(!name || !package || !code) {
    return null
  }
  
  orientation = (orientation || 'portrait').toLowerCase()
  let templatePath = path.join(__dirname, 'temps', bigOneLetter(orientation)+".zip")
  
  let projectPath = path.join(__dirname, 'projects', String(id))

  fs.mkdirSync(projectPath)
  extractAll(templatePath, projectPath)
  modifyApp(projectPath, name, 'code.aide.webview', package)
  codeParse(code, projectPath)

  if(iconPath !== null) fs.writeFileSync(path.join(projectPath, './app/src/main/res/drawable/icon.png'), fs.readFileSync(iconPath))

  newZip(path.join((output || (path.join(__dirname, 'outputs'))), `${id}-aide-${name}-${package}-project.zip`), projectPath)
  return path.join((output || (path.join(__dirname, 'outputs'))), `${id}-aide-${name}-${package}-project.zip`)
}
function bigOneLetter(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
function extractAll(zip, folder) {
  (new AdmZip(zip)).extractAllTo(folder, true)
}
function newZip(zipPath, filesPath) {
  let zip = new AdmZip()

  zip.addLocalFolder(filesPath)

  zip.writeZip(zipPath)
  fs.rmSync(filesPath, {recursive:true})
}

module.exports = newApp