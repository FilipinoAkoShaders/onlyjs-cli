const fs = require('fs')
const path = require('path')

module.exports = function(code, projectPath) {
  let rendererPath = path.join(projectPath, './app/src/main/assets/render.html')
  let contents = fs.readFileSync(rendererPath, "utf-8")

  let body = code 
  .replaceAll('$Android', 'android')
  .replaceAll('$body', 'document.body')

  let imports = ""
  
  body.split('\n').filter(v=>v.startsWith('$import ')).forEach(v => {
    let importUrl = v.replaceAll('$import ', '')
    importUrl = importUrl
    .replaceAll('`')
    .replaceAll('"')
    .replaceAll("'")
    
    imports=imports+"\n"+`<script src="${importUrl}"></script>`
  })

  contents = contents.replace('$SCRIPT', body).replace('$IMPORTS', imports)
  fs.writeFileSync(rendererPath, contents)

  return true
}