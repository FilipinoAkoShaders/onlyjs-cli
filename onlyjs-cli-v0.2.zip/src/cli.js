const { program } = require('commander')
const newApp = require('./OnlyJS.js')
const db = require('./db.js')(__dirname+'/db.json')
const fs = require('fs')
const path = require('path')

program
.name('OnlyJS')
.description('Create an Android app or Game using only 1 JavaScript File')
.version(fs.readFileSync(path.resolve(__dirname+'/ver.txt'), 'utf-8'))

program.command('init')
.description('create a project')
.option('-n, --name <string>', 'your project name')
.action((data, options) => {
  options = options._optionValues || options
  if(!options) return console.error('options: missing')
  
  if(typeof options.name !== "string") return console.error('Error: invalid project name')

  let acsId = String(Math.floor(Math.random()*(999999 - 111111 + 1)+111111))
  
  db.set(acsId, { id: acsId, name: options.name, package: 'code.onlyjs.'+options.name.toLowerCase(), orientation: 'portrait', code: null, iconPath: null })

  console.log('A project with the name of '+options.name+' [access id: '+acsId+']')
})

program.command('package')
.argument('<packageName>', 'the package name you want to put!')
.option('-i, --accessId <id>', 'the access id of your project')
.action((data, options) => {
  options = options._optionValues || options

  if(!options) return console.error('options: missing')
  
  if(typeof data !== "string") return console.error('Error: invalid package name')
  if(typeof options.accessId !== "string") return console.error('Error: invalid project id')

  if(!validity('pkg', data)) return console.error('Error: invalid package name!')
  if(!validity('db', options.accessId)) return console.error('Error: invalid project id!')
  
  editInfo('package', data, options.accessId)
  console.log('success!')
})

program.command('orientation')
.argument('<orientation>', 'the orientation of the app!')
.option('-i, --accessId <id>', 'the access id of your project')
.action((data, options) => {
  options = options._optionValues || options
  if(!options) return console.error('options: missing')
  
  if(typeof data !== "string") return console.error('Error: invalid orientation')
  if(typeof options.accessId !== "string") return console.error('Error: invalid project id')

  if(!validity('orientation', data)) return console.error('Error: invalid orientation!')
  if(!validity('db', options.accessId)) return console.error('Error: invalid project id!')
  
  editInfo('orientation', data.toLowerCase(), options.accessId)
  console.log('success!')
})

program.command('icon')
.argument('<iconPath>', 'the icon path for the app!')
.option('-i, --accessId <id>', 'the access id of your project')
.action((data, options) => {
  options = options._optionValues || options
  if(!options) return console.error('options: missing')
  
  if(typeof data !== "string") return console.error('Error: invalid icon path')
  if(typeof options.accessId !== "string") return console.error('Error: invalid project id')

  if(!validity('file', data)) return console.error('Error: invalid icon path!')
  if(!validity('db', options.accessId)) return console.error('Error: invalid project id!')
  
  editInfo('iconPath', path.resolve(data), options.accessId)
  console.log('success!')
})

program.command('code')
.argument('<codeFile>', 'the main code of your app!')
.option('-i, --accessId <id>', 'the access id of your project')
.action((data, options) => {
  options = options._optionValues || options
  if(!options) return console.error('options: missing')
  
  if(typeof data !== "string") return console.error('Error: invalid file path')
  if(typeof options.accessId !== "string") return console.error('Error: invalid project id')

  if(!validity('file_js', data)) return console.error('Error: invalid file path!')
  if(!validity('db', options.accessId)) return console.error('Error: invalid project id!')
  
  editInfo('code', fs.readFileSync(path.resolve(data), 'utf-8'), options.accessId)
  console.log('success!')
})

program.command('publish')
.option('-O, --output <dir>', 'the path output')
.option('-i, --accessId <id>', 'the access id of your project')
.action((data, options) => {
  options = options._optionValues || options
  if(!options) return console.error('options: missing')
  
  if(typeof options.output !== "string") return console.error('Error: invalid file path')
  if(typeof options.accessId !== "string") return console.error('Error: invalid project id')

  if(!validity('file', options.output)) return console.error('Error: invalid file path!')
  if(!validity('db', options.accessId)) return console.error('Error: invalid project id!')
  
  let got = newApp(options.output, db.get(options.accessId), options.accessId)

  if(got === null) return console.error('Error: project not completly modified!')

  console.log('==> '+got)
  deleteInfo(options.accessId)
  console.log('DONE! now import this zip to aide, and PUBLISH and your done!')
})

function validity(key, value) {
  if(key === 'pkg') {
    let pg = value.split('.')

    return (pg.length > 1)
  } else if(key === 'db') {
    return db.get(value) ? true : false
  } else if(key === 'orientation') {
    return (value.toLowerCase() === "portrait" ? true : (value.toLowerCase() === "landscape" ? true : false))
  } else if(key === 'file') {
    return fs.existsSync(path.resolve(value))
  } else if(key === 'file_js') {
    return fs.existsSync(path.resolve(value)) && value.endsWith('.js')
  } else return false
}
function editInfo(key, value, db_) {
  let cur_val = db.get(db_)
  cur_val[key] = value
  db.set(db_, cur_val)
}
function deleteInfo(db_) {
  let cur_val = db.get(db_)
  cur_val = {}
  db.set(db_, cur_val)
}

program.parse()